# État des lieux — sauvegarde consolidée DODECA_T2G

Date UTC : 2026-11-27T16:18:41.502307+00:00

## Résultat matériel

- Fichiers projet copiés : 21/21
- Empreintes SHA-256 vérifiées après copie : 21/21
- Sources : 9 fichiers de la sauvegarde V21 + 12 fichiers récupérés depuis GitHub
- Manifeste : `MANIFESTE_CONSOLIDE.json`
- Provenance : dossier `provenance/`
- Transcriptions manuelles : 0

## Scripts dont la syntaxe a été contrôlée

- V15C3_EXTRACTION_SOUSRESULTANT.py
- V15C4_MODULAR_LAMBDA.py
- V16_2_AUDIT_LAMBDA_RECONCILIATION.py
- V18_RESOLUTION_EXACTE.py
- V19_TEST_BASE.py
- V20_DIAGNOSTIC_CRT.py
- V21_EXTENSION_CRT.py

La compilation syntaxique ne démontre pas la validité mathématique des résultats.

## Réserves

- Cette archive consolide des fichiers, elle ne relance aucun calcul.
- Les transcriptions de conversations ChatGPT ne sont pas automatiquement accessibles.
- Les statuts mathématiques restent ceux des rapports et journaux existants ; aucune nouvelle validation mathématique n'est revendiquée.
- Les originaux et les sauvegardes précédentes sont conservés sans modification.
