import json
import sympy as sp

R = sp.symbols("r")
pfile = "RESULTANT_SCHUR_T2G_V10_EXACT.txt"

def assignment(key):
    for line in open(pfile, encoding="utf-8"):
        if line.startswith(key+"="):
            return line.split("=",1)[1].strip()
    raise ValueError(key+" absent")

H = sp.Poly(sp.sympify(assignment("H"), locals={"r":R}), R, domain=sp.QQ)
S10 = sp.Poly(sp.sympify(open("S10_reduit_num.txt").read(), locals={"r":R}), R, domain=sp.QQ)
S11 = sp.Poly(sp.sympify(open("S11_reduit_num.txt").read(), locals={"r":R}), R, domain=sp.QQ)

D = int(H.LC())
crt = json.load(open("V9_CRT_RESIDUES_001.json"))
primes = crt["collection_primes"]
residues = [int(x) for x in crt["residues_beta_power_basis"]]

def modpoly(P,p):
    e=0
    for (i,),c in P.terms():
        c=sp.Rational(c)
        e += (int(c.p)*pow(int(c.q),-1,p)%p)*R**i
    return sp.Poly(e,R,modulus=p)

print("D chargé :", len(str(abs(D))), "chiffres")
print("Départs :", H.degree(), S10.degree(), S11.degree())
print("Coordonnées CRT :",len(residues))

for p in [397,523,569,653]:
    if p not in primes:
        print("PREMIER ABSENT",p)
        continue
    Hp=modpoly(H,p)
    A=modpoly(S11,p)
    B=modpoly(S10,p)
    if Hp.degree()!=39 or sp.gcd(A,Hp).degree()!=0:
        print("PREMIER NON VALIDE",p)
        continue
    lam=(-B*sp.invert(A,Hp)).rem(Hp)
    dinv=pow(D%p,-1,p)
    beta=[int(lam.nth(i))*pow(dinv,i,p)%p for i in range(39)]
    bad=[i for i in range(39) if beta[i] != residues[i]%p]
    print("\np =",p)
    print("Identité mod H :", (A*lam+B).rem(Hp).is_zero)
    print("Concordance CRT :",39-len(bad),"/ 39")
    print("Indices en échec :",bad)
