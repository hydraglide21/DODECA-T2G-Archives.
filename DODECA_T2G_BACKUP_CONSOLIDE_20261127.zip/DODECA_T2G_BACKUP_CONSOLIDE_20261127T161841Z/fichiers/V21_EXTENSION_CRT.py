#!/usr/bin/env python3
# V21 — Extension CRT de 250 à 275 premiers.
# Ne modifie aucun fichier d'archive existant.

import sympy as sp
import json, math, hashlib
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
R = sp.symbols("r")

F_H = ROOT / "RESULTANT_SCHUR_T2G_V10_EXACT.txt"
F_S10 = ROOT / "S10_reduit_num.txt"
F_S11 = ROOT / "S11_reduit_num.txt"
F_CRT = ROOT / "V9_CRT_RESIDUES_001.json"

for f in (F_H, F_S10, F_S11, F_CRT):
    if not f.is_file():
        raise FileNotFoundError("Fichier absent : " + f.name)

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_H():
    for line in F_H.read_text(encoding="utf-8").splitlines():
        if line.startswith("H="):
            return sp.Poly(
                sp.sympify(line.split("=", 1)[1], locals={"r": R}),
                R, domain=sp.QQ
            )
    raise ValueError("Affectation H= introuvable")

def read_poly(path):
    return sp.Poly(
        sp.sympify(path.read_text(encoding="utf-8"), locals={"r": R}),
        R, domain=sp.QQ
    )

def mod_poly(P, p):
    expr = 0
    for (i,), c in P.terms():
        c = sp.Rational(c)
        den = int(c.q) % p
        if den == 0:
            raise ZeroDivisionError("Dénominateur divisible par p")
        coeff = (int(c.p) % p) * pow(den, -1, p) % p
        expr += coeff * R**i
    return sp.Poly(expr, R, modulus=p)

def lambda_beta(H, S10, S11, D, p):
    Hp = mod_poly(H, p)
    A = mod_poly(S10, p)
    B = mod_poly(S11, p)

    if Hp.degree() != 39:
        raise ValueError("Degré H réduit incorrect")
    if D % p == 0:
        raise ValueError("D non inversible")
    if sp.gcd(B, Hp).degree() != 0:
        raise ValueError("S11 non inversible modulo H")

    invB = sp.invert(B, Hp)
    L = (-A * invB).rem(Hp)

    if not (B * L + A).rem(Hp).is_zero:
        raise AssertionError("Identité modulaire en échec")

    Dinv = pow(D % p, -1, p)
    return [
        int(L.nth(i)) * pow(Dinv, i, p) % p
        for i in range(39)
    ]

def rational_reconstruct(a, m):
    bound = math.isqrt((m - 1) // 2)
    a %= m
    r0, r1 = m, a
    t0, t1 = 0, 1

    while r1 > bound:
        q = r0 // r1
        r0, r1 = r1, r0 - q * r1
        t0, t1 = t1, t0 - q * t1

    num, den = r1, t1
    if den < 0:
        num, den = -num, -den

    if den == 0 or abs(num) > bound or den > bound:
        return None
    if math.gcd(num, den) != 1:
        return None
    if (num - a * den) % m != 0:
        return None
    return (int(num), int(den))

print("=== V21 — EXTENSION CRT ===")

H = read_H()
S10 = read_poly(F_S10)
S11 = read_poly(F_S11)

assert H.degree() == 39
assert S10.degree() == 38 and S11.degree() == 38
assert sp.gcd(S11, H).degree() == 0

Dq = H.LC()
assert Dq.q == 1 and int(Dq) != 0
D = int(Dq)

crt = json.loads(F_CRT.read_text(encoding="utf-8"))
primes = [int(x) for x in crt["collection_primes"]]
residues = [int(x) for x in crt["residues_beta_power_basis"]]
M = int(crt["crt_modulus"])

assert len(primes) == 250
assert len(set(primes)) == 250
assert len(residues) == 39
assert math.prod(primes) == M

print("Archive V9 : 250 premiers")
print("Module initial :", len(str(M)), "chiffres")
print("PGCD exact(S11,H) : PASS")

# Témoins réservés : jamais intégrés au CRT.
holdouts = [227, 4057, 4211]
holdout_vectors = {
    p: lambda_beta(H, S10, S11, D, p)
    for p in holdouts
}
print("Trois témoins indépendants calculés : PASS")

# Chercher 25 nouveaux premiers après le plus grand ancien.
new_primes = []
p = int(sp.nextprime(max(primes)))

while len(new_primes) < 25:
    if p not in primes and p not in holdouts:
        try:
            vec = lambda_beta(H, S10, S11, D, p)
            new_primes.append((p, vec))
            print("Nouveau premier", len(new_primes), "/25 :", p)
        except (ValueError, ZeroDivisionError):
            print("Premier écarté :", p)
    p = int(sp.nextprime(p))

# Extension CRT coordonnée par coordonnée.
for p, vec in new_primes:
    Minv = pow(M % p, -1, p)
    new_residues = []
    for old, a in zip(residues, vec):
        t = ((a - old) % p) * Minv % p
        new_residues.append(old + M * t)
    residues = new_residues
    M *= p

# Vérification des 25 nouvelles congruences.
for p, vec in new_primes:
    assert all(
        (residues[i] - vec[i]) % p == 0
        for i in range(39)
    )

print("Extension CRT : PASS")
print("Nombre total de premiers :", len(primes) + len(new_primes))
print("Nouveau module :", len(str(M)), "chiffres")

# Reconstruction rationnelle et contrôle indépendant.
fractions = []
for i, a in enumerate(residues):
    rr = rational_reconstruct(a, M)
    if rr is None:
        fractions.append(None)
    else:
        fractions.append({
            "numerator": rr[0],
            "denominator": rr[1]
        })

checks = []
for i, frac in enumerate(fractions):
    if frac is None:
        checks.append({
            "coordinate": i,
            "status": "NOT_RECONSTRUCTED"
        })
        continue

    num = frac["numerator"]
    den = frac["denominator"]
    tests = {}

    for p in holdouts:
        if den % p == 0:
            tests[str(p)] = "NON_TESTABLE"
        else:
            v = holdout_vectors[p][i]
            tests[str(p)] = (
                "PASS" if (num - v * den) % p == 0 else "FAIL"
            )

    checks.append({
        "coordinate": i,
        "numerator": num,
        "denominator": den,
        "holdouts": tests
    })

reconstructed = sum(x is not None for x in fractions)
all_holdouts_pass = (
    reconstructed == 39
    and all(
        all(v == "PASS" for v in x["holdouts"].values())
        for x in checks
    )
)

stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
report = {
    "schema": "DODECA_T2G_V21_CRT_EXTENSION",
    "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    "status": (
        "39_CANDIDATES_PASS_3_HOLDOUTS__EXACT_IDENTITY_NOT_YET_TESTED"
        if all_holdouts_pass
        else "CRT_EXTENDED__RATIONAL_RECONSTRUCTION_NOT_CERTIFIED"
    ),
    "initial_prime_count": 250,
    "new_primes": [p for p, _ in new_primes],
    "total_prime_count": len(primes) + len(new_primes),
    "crt_modulus": str(M),
    "crt_modulus_digits": len(str(M)),
    "residues_beta_power_basis": [str(x) for x in residues],
    "reconstructed_count": reconstructed,
    "fractions_beta_basis": fractions,
    "independent_holdouts": holdouts,
    "holdout_checks": checks,
    "input_sha256": {
        "H_source": sha256(F_H),
        "S10": sha256(F_S10),
        "S11": sha256(F_S11),
        "V9_CRT": sha256(F_CRT)
    }
}

out = ROOT / f"RAPPORT_V21_EXTENSION_{stamp}.json"
if out.exists():
    raise FileExistsError(out)
out.write_text(
    json.dumps(report, indent=2, ensure_ascii=False) + "\n",
    encoding="utf-8"
)

print("\n=== BILAN V21 ===")
print("Nouveaux premiers :", len(new_primes))
print("Total :", len(primes) + len(new_primes))
print("Fractions reconstruites :", reconstructed, "/39")
print("Témoins tous PASS :", all_holdouts_pass)
print("Rapport créé :", out.name)
print("STATUT :", report["status"])
