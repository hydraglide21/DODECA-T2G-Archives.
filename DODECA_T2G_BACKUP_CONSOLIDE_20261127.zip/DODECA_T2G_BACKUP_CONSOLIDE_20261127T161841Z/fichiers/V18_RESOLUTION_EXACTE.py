import json
import hashlib
from pathlib import Path
import sympy as sp
from sympy.polys.matrices import DomainMatrix
from sympy.polys.domains import ZZ

ROOT = Path.cwd()
r = sp.Symbol("r")

def lire_affectation(path, key):
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith(key + "="):
            return line.split("=", 1)[1].strip()
    raise ValueError(f"{key}= introuvable")

print("=== V18 — REPRISE EXACTE ===", flush=True)

# 1. Charger les sources
H = sp.Poly(
    sp.sympify(lire_affectation(
        ROOT / "RESULTANT_SCHUR_T2G_V10_EXACT.txt", "H"
    ), locals={"r": r}),
    r, domain=sp.QQ
)
S10 = sp.Poly(
    sp.sympify(
        (ROOT / "S10_reduit_num.txt").read_text(),
        locals={"r": r}
    ), r, domain=sp.QQ
)
S11 = sp.Poly(
    sp.sympify(
        (ROOT / "S11_reduit_num.txt").read_text(),
        locals={"r": r}
    ), r, domain=sp.QQ
)

assert H.degree() == 39
assert S10.degree() == 38
assert S11.degree() == 38
assert sp.gcd(S11, H).degree() == 0

print("Sources exactes : PASS", flush=True)

# 2. Charger et contrôler V17
report_path = ROOT / "RAPPORT_V17_RECONSTRUCTION_20261126T192848Z.json"
data = json.loads(report_path.read_text(encoding="utf-8"))
fractions = data["fractions_r_basis"]

assert len(fractions) == 39
assert data["reconstructed_count"] == 28
assert data["crt_all_match"] is True
assert data["v15c4_all_match"] is True
assert data["prime_count_used"] == 250

known = {}
missing = []

for i, item in enumerate(fractions):
    if item is None:
        missing.append(i)
    else:
        known[i] = sp.Rational(
            int(item["numerator"]),
            int(item["denominator"])
        )

assert len(known) == 28
assert len(missing) == 11

print("Coefficients connus :", len(known), flush=True)
print("Indices inconnus :", missing, flush=True)

# 3. Construire le système A*x=b
known_poly = sp.Poly(
    sum((c*r**i for i, c in known.items()), sp.S.Zero),
    r, domain=sp.QQ
)
base = (S11 * known_poly + S10).rem(H)

columns = []
for i in missing:
    e = (S11 * sp.Poly(r**i, r, domain=sp.QQ)).rem(H)
    columns.append([e.nth(j) for j in range(39)])

A = sp.Matrix(39, 11, lambda j, k: columns[k][j])
b = sp.Matrix([-base.nth(j) for j in range(39)])

print("Matrice construite : 39 x 11", flush=True)

# 4. Sélection modulaire de 11 lignes indépendantes
def modq(q, p):
    q = sp.Rational(q)
    return (int(q.p) % p) * pow(int(q.q) % p, -1, p) % p

p = int(sp.nextprime(1000003))

while any(
    int(sp.Rational(q).q) % p == 0
    for q in list(A) + list(b)
):
    p = int(sp.nextprime(p))

R = [
    [modq(A[i, j], p) for i in range(39)]
    for j in range(11)
]

pivot_rows = []
row = 0

for col in range(39):
    pivot = next(
        (k for k in range(row, 11) if R[k][col] != 0),
        None
    )
    if pivot is None:
        continue

    R[row], R[pivot] = R[pivot], R[row]
    inv = pow(R[row][col], -1, p)
    R[row] = [(v * inv) % p for v in R[row]]

    for k in range(11):
        if k != row:
            factor = R[k][col]
            if factor:
                R[k] = [
                    (R[k][j] - factor * R[row][j]) % p
                    for j in range(39)
                ]

    pivot_rows.append(col)
    row += 1
    if row == 11:
        break

print("Premier de sélection :", p, flush=True)
print("Rang modulaire :", row, flush=True)

assert row == 11, "Rang modulaire inférieur à 11"

# 5. Former le système carré entier
B_rows = []
Y_rows = []

for i in pivot_rows:
    values = [sp.Rational(A[i, j]) for j in range(11)]
    rhs = sp.Rational(b[i])
    den = int(sp.ilcm(*[int(q.q) for q in values + [rhs]]))
    B_rows.append([int(q * den) for q in values])
    Y_rows.append([int(rhs * den)])

B = sp.Matrix(B_rows)
Y = sp.Matrix(Y_rows)

print("Système carré 11 x 11 prêt", flush=True)
print("Résolution rationnelle exacte en cours...", flush=True)

# 6. Résolution exacte par dénominateur commun
BD = DomainMatrix.from_Matrix(B).convert_to(ZZ)
YD = DomainMatrix.from_Matrix(Y).convert_to(ZZ)

B_inv_num, determinant = BD.inv_den()
X_num = (B_inv_num * YD).to_Matrix()

solution = [
    sp.Rational(X_num[i, 0], int(determinant))
    for i in range(11)
]

print("Les 11 valeurs ont été calculées.", flush=True)

# 7. Vérifier les 39 équations
residual = A * sp.Matrix(solution) - b
bad = [i for i in range(39) if residual[i] != 0]

print("Équations satisfaites :", 39-len(bad), "/ 39", flush=True)

if bad:
    print("Équations en échec :", bad)
    print("STATUT : SYSTEME_INCOMPATIBLE")
    raise SystemExit(1)

all_coeffs = dict(known)
for i, value in zip(missing, solution):
    all_coeffs[i] = sp.cancel(value)

LAMBDA = sp.Poly(
    sum((all_coeffs[i]*r**i for i in range(39)), sp.S.Zero),
    r, domain=sp.QQ
)

remainder = (S11 * LAMBDA + S10).rem(H)
assert remainder.is_zero

# 8. Rapport V18 sans écraser les archives
result = {
    "schema": "DODECA_T2G_V18_EXACT_RECONSTRUCTION",
    "source_v17": report_path.name,
    "source_v17_sha256": hashlib.sha256(report_path.read_bytes()).hexdigest(),
    "known_count": len(known),
    "reconstructed_missing_count": len(solution),
    "missing_indices": missing,
    "modular_selection_prime": p,
    "modular_rank": row,
    "equations_satisfied": 39,
    "exact_identity": True,
    "fractions_r_basis": [
        {
            "numerator": str(all_coeffs[i].p),
            "denominator": str(all_coeffs[i].q)
        }
        for i in range(39)
    ],
    "status": "EXACT_IDENTITY_PASS"
}

out = ROOT / "RAPPORT_V18_RECONSTRUCTION_EXACTE.json"
assert not out.exists(), "Le rapport existe déjà : arrêt sans écrasement."
out.write_text(json.dumps(result, indent=2), encoding="utf-8")

print("\n=== BILAN V18 ===")
print("39 coefficients :", len(all_coeffs))
print("Identité exacte :", remainder.is_zero)
print("Rapport :", out.name)
print("STATUT : EXACT_IDENTITY_PASS")
