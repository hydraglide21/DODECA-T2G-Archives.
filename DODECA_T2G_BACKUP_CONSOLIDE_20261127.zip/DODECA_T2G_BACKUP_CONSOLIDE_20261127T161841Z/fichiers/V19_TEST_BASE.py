import json
import sympy as sp
from pathlib import Path

r = sp.Symbol("r")
root = Path.cwd()

def assignment(path, key):
    for line in path.read_text().splitlines():
        if line.startswith(key + "="):
            return line.split("=", 1)[1].strip()
    raise ValueError(key + " absent")

H = sp.Poly(
    sp.sympify(assignment(root/"RESULTANT_SCHUR_T2G_V10_EXACT.txt", "H"),
               locals={"r": r}), r, domain=sp.QQ)

S10 = sp.Poly(
    sp.sympify((root/"S10_reduit_num.txt").read_text(),
               locals={"r": r}), r, domain=sp.QQ)

S11 = sp.Poly(
    sp.sympify((root/"S11_reduit_num.txt").read_text(),
               locals={"r": r}), r, domain=sp.QQ)

report = json.loads(
    (root/"RAPPORT_V17_RECONSTRUCTION_20261126T192848Z.json")
    .read_text()
)
fractions = report["fractions_r_basis"]

D = int(H.LC())

def reduce_mod(P, p):
    expr = 0
    for (i,), c in P.terms():
        c = sp.Rational(c)
        den = int(c.q) % p
        if den == 0:
            raise ZeroDivisionError(f"Dénominateur divisible par {p}")
        coeff = int(c.p) * pow(den, -1, p) % p
        expr += coeff * r**i
    return sp.Poly(expr, r, modulus=p)

print("=== V19 : TEST DES DEUX BASES ===")
print("D : chargé depuis le coefficient dominant de H")
print("Degré H :", H.degree())

for p in [4057, 4211]:
    Hp = reduce_mod(H, p)
    A10 = reduce_mod(S10, p)
    A11 = reduce_mod(S11, p)

    if D % p == 0:
        print("Premier inutilisable : D divisible par", p)
        continue

    if sp.gcd(A11, Hp).degree() != 0:
        print("Premier inutilisable : S11 non inversible modulo", p)
        continue

    lam = (-A10 * sp.invert(A11, Hp)).rem(Hp)
    Dinv = pow(D % p, -1, p)

    r_ok = 0
    beta_ok = 0
    tested = 0

    for i, item in enumerate(fractions):
        if item is None:
            continue

        num = int(item["numerator"])
        den = int(item["denominator"])

        if den % p == 0:
            continue

        candidate = (num % p) * pow(den % p, -1, p) % p
        actual_r = int(lam.nth(i)) % p
        actual_beta = actual_r * pow(Dinv, i, p) % p

        tested += 1
        if candidate == actual_r:
            r_ok += 1
        if candidate == actual_beta:
            beta_ok += 1

    print("\nPREMIER :", p)
    print("Fractions testées :", tested)
    print("Concordances en base r :", r_ok)
    print("Concordances en base beta :", beta_ok)

print("\nFIN DU TEST")
