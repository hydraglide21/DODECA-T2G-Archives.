# DODECA_T2G — POINT DE REPRISE
Date : 27 novembre 2026

## Statuts et précautions
Distinguer démontré/reproduit, rapporté par exécution utilisateur, rapporté dans un document, conditionnel, ouvert et non exécuté. Ne jamais présenter une concordance modulaire comme une reconstruction rationnelle exacte. Ne jamais écraser les archives.

## Reconstruction CRT / lambda
- V9 : `V9_CRT_RESIDUES_001.json`, 250 premiers, 39 coordonnées ; rapport V17 : module CRT de 1136 chiffres.
- V15C3 : extraction de `F_red`, `G`, `H`; degrés lambda 13 et 9, degré r de H égal à 39; sous-résultant linéaire extrait; S10/S11 réduits modulo H. L'inverse rationnelle exacte reste à établir.
- V15C4/V16.2 : identité modulaire `(S11*lambda+S10) mod H = 0`. Base r `1,r,...,r^38`.
- Conversion de base : `beta=D*r`, `D=lc(H)` ; coefficient r `a_i` vers beta : `a_i/D^i mod p`.
- V17 : 28 fractions candidates sur 39, 11 manquantes; 250 premiers; module 1136 chiffres. Les candidats échouent aux témoins indépendants et ne sont pas certifiés.
- V18 (`V18_RESOLUTION_EXACTE.py`) : 11 valeurs calculées, 11/39 équations satisfaites, indices 11 à 38 en échec, statut `SYSTEME_INCOMPATIBLE`. Témoins : p=227, 0/27 (index 17 non testable); p=4057 et 4211, 0/28.
- V19 (`V19_TEST_BASE.py`) : test r contre beta=Dr ; résultat ultérieur rapporté : 0/28 aux témoins 4057 et 4211 dans les deux bases.
- V20 (`V20_DIAGNOSTIC_CRT.py`) : exécuté dans Termux. D=lc(H) a 111 chiffres ; degrés H/S10/S11=39/38/38 ; 39 coordonnées ; p=397,523,569,653 : identité mod H vraie et concordance CRT 39/39, aucun indice en échec. Cela valide ces quatre contrôles, pas les fractions V17.
- V21 (`V21_EXTENSION_CRT.py`) : préparé/enregistré selon la dernière discussion ; aucune exécution confirmée. Ne pas le marquer PASS avant journal.

## Géométrie du cube 59 DDL
- Secteurs : Eg=20, T2g=39.
- Matrices complètes rapportées : Eg 14 champs du noyau + 6 relèvements ; T2g 30 + 9. Relèvement `U_p=(xp,yp,zp)/(deg(p)+3)`.
- Rangs T2g rapportés : M_T=39, K0_T=39, Kd_T=9, C_T=3.
- V16.1 rapporté dans `01_CUBE_59_DDL.md` : 13 entrelaceurs 39x3 ; S_T 39x39 ; det(S_T)=3/128 ; `S_T^T A S_T = I_3 ⊗ A_T,13`, A_T,13 13x13.
- Cette réduction est rapportée comme exacte, mais la reproduction indépendante complète reste à faire.
- Une autre décomposition par involution, issue de `V3_3_5_CONTROLE_EXACT_M_K0_KD.py`, donne pour T2g 26+13. Ne pas confondre avec 3x13.
- `F_red` degré 13 en lambda, `G` degré 9, `H` degré 39 en r. Question ouverte : `F_red(lambda,r) = det(lambda I_13 - A_T,13(r))` ? Non démontré.

## Dépôt GitHub
Dépôt exact : `hydraglide21/DODECA-T2G-Archives.` (point final inclus).
Inspection du 27-11-2026 : 86 fichiers, arbre non tronqué. Dernier commit observé `55b0e5c561c144697f3ff328f7a6d536e7f8f312`, 2026-11-27 05:08:01 UTC, ajout du rapport V17. V18/V19/V20/V21 non présents dans l'arbre GitHub inspecté, bien que plusieurs soient rapportés dans Termux.

## Fichiers à préserver
`RESULTANT_SCHUR_T2G_V10_EXACT.txt`, `S10_reduit_num.txt`, `S10_reduit_den.txt`, `S11_reduit_num.txt`, `S11_reduit_den.txt`, `V9_CRT_RESIDUES_001.json`, `RAPPORT_RECONSTRUCTION_CRT_LAMBDA_V6.json`, `RAPPORT_V17_RECONSTRUCTION_20261126T192848Z.json`, `V15C3_EXTRACTION_SOUSRESULTANT.py`, `V15C3_EXTRACTION_REPORT.json`, `V15C4_MODULAR_LAMBDA.py`, `V15C4_MODULAR_LAMBDA.json`, `V16_2_AUDIT_LAMBDA_RECONCILIATION.py`, `V18_RESOLUTION_EXACTE.py`, `V19_TEST_BASE.py`, `V20_DIAGNOSTIC_CRT.py`, `V21_EXTENSION_CRT.py`, ainsi que les journaux Termux et les sources géométriques V16.1.

## Suite
1. Vérifier V21 puis l'exécuter en conservant la sortie complète.
2. Étendre le CRT dans de nouveaux fichiers, sans écraser V9/V17.
3. Rechercher les sources exactes de A, S_T et A_T,13.
4. Reproduire `S_T^T A S_T = I_3 ⊗ A_T,13`.
5. Tester ensuite seulement le lien entre F_red et le déterminant 13x13.


## Inventaire automatique de cette exécution
- Date UTC : 2026-11-27T15:12:11.672648+00:00
- Racine locale : `/data/data/com.termux/files/home/DODECA_T2G`
- Fichiers de projet copiés : 9
- Transcriptions ajoutées manuellement : 0
